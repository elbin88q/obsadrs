<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Birth And Death Registrations</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
    <header>
      <div class="logo">
        <a href="">OBADCR</a>
      </div>
     <div class="navcontainer">
            <nav class="navbar">
              <ul>

                <li>             
                    <a href="index.php">HOME</a>
                </li>
                <li>
                    <a href="user/login.php">USER</a>
                </li>
                <li>
                    <a href="user/search.php">VERIFY CERTIFICATE</a>
                </li>
                <li>
                    <a href="admin/login.php">ADMIN</a>
                </li>
                   
                

              </ul>
            </nav>
     </div>
    </header>


    <div class="banner animated-img">
    <h1 class="quote">ONLINE BIRTH AND DEATH CERTIFICATE REGISTRATION</h1>
    <p>THROUGH EASY STEPS AND ONLINE</p>
    </div>

    </div>
 <br>
 <br>
 <h1 class="name" style="font-weight: bold; text-align: center;">Making Things Easy</h1><br>
    <article>
        <section class="about">
            <p >
            Introducing OBADCR – Your Convenient Certificate Registration Hub
            </p>
            <p>
            Tired of bureaucratic hassles? OBADCR is your solution for quick and hassle-free birth and death 
            certificate registration. With just a few clicks, you can create your account, log in, and efficiently 
            complete your certificate registration process. Say hello to simplicity and accuracy with OBADCR!
            </p>
           
            
    </section><br>
        <div class="cards">
            <div class="review">
              <h1 class="stats">24 Hour</h1>
              <h4>Help and</h4>
              <p>Customer Service</p>
            </div>
            <div class="review">
              <h1 class="stats">Questions?</h1>
              <h4>Contact US</h4>
              <p>or have chat with us</p>
            </div>
            <div class="review">
              <h1 class="stats">Instant</h1>
              <h4>Registrations</h4>
              <p>And printable Certificates</p>
            </div>
            <div class="review">
              <h1 class="stats">Easy</h1>
              <h4>Fast and</h4>
              <p>More Efficient</p>
            </div>
          </div>
    </article>

 <br>
 <section>
    <div class="styl">
      <div class="img_menu">

      </div>
      <div class="menu">
      <ul>
    <li><h1>START</h1></li>
    <li><h1>BY SIMPLY</h1></li>
    <li><h1>LOGGING IN</h1></li>
    <li><h1>OR CREATE AN ACCOUNT</h1></li>
    <li><h1>WITH US</h1></li>
     </ul>
    <a href="user/login.php"><button class="login">LOGIN</button></a>
      </div>
        

    </div>    
 </section>

 

 <div class="wrapper">
    <h1>Our Team</h1>
    <div class="our_team">
    <div class="team_member">
           <div class="member_img">
             <img src="img/member_1.png" alt="our_team">
          </div>
          <h3>Ganesh Bhattarai</h3>
          <span>S20230595</span>
      </div>
        
        <div class="team_member">
           <div class="member_img">
             <img src="img/member_1.png" alt="our_team">
            
          </div>
          <h3>Pravesh Adhikari</h3>
          <span>S20230461</span>
      </div>
      <div class="team_member">
          <div class="member_img">
             <img src="img/albin.png" alt="our_team">
          </div>
          <h3>albin rai</h3>
          <span>S20230515</span>
          <p>I did what i did rest is up to them.</p>
        </div>
        <div class="team_member">
           <div class="member_img">
             <img src="img/member_1.png" alt="our_team">
             
          </div>
          <h3>Shikhar G C</h3>
          <span>S20230168</span>
      </div>  
      <div class="team_member">
           <div class="member_img">
             <img src="img/member_1.png" alt="our_team">
          </div>
          <h3>Bikram Shrestha</h3>
          <span>S20221173</span>
      </div>
    </div>
</div>	

<h1 class="thanks">THANK YOU!</h1>
<br>
<br>
</div>
<footer>

<div class="footer-text">
                                <p>Online Birth And Death Certificate System </p>
                            
                            <div class="footer-nav">
                                <nav>
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="admin/login.php">Admin</a></li>
                                        <li><a href="user/login.php">User</a></li>
                                      
                                    </ul>
                                </nav>
                            </div>
</div>                            
</footer>
    <div class="copyright">
      <p>&copy;2023 Copyright</p>
      <p>Above images are used for only educational purposes</p>
    </div>
 

</body>
</html>
<?php

?>